# Freshslice Pizza – Lougheed Town Centre website

A responsive, single-page static website concept.

## Files
- `index.html` — complete website (HTML, CSS and JavaScript in one file)

## Preview locally
Open `index.html` in a web browser.

## Free hosting with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, e.g. `freshslice-lougheed`.
2. Upload `index.html` to the repository's top level.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The address will look like:
   `https://YOUR-USERNAME.github.io/freshslice-lougheed/`

## Before publishing
- Confirm that you have permission to use the Freshslice name, logo, brand assets and menu content.
- Confirm the store phone number and hours.
- Confirm that the DoorDash / online ordering URL still points to this exact store.
- Add the exact Lougheed branch SkipTheDishes URL if the branch is listed there. The current Skip button opens Skip's website rather than a confirmed branch-specific page.
- Verify menu items, descriptions, prices, sizes, taxes and availability with the store. Prices shown are sample highlights and may change.
- Consider adding approved food photography, an official logo, privacy information and analytics.
